$increment = 6
$tile = 1
$size = 224
$sourceFile = "C:\onedrive\main_projects\render\commercial\butterfly\close_03.jpg"

$resX = 1920
$resY = 1080

$rowCount = [Math]::Floor($resY / $size) + 1
$colCount = [Math]::Floor($resX / $size) + 1

for($row = 0; $row -lt $rowCount; $row++)
{
	for($col = 0; $col -lt $colCount; $col++)
	{
		$outFile = "tile0{0}" -f $tile

		if($tile -gt 9)
		{
			$outFile = "tile{0}" -f $tile
		}

		$cornerX = ($size * ($col)) - ($increment * $col)
		$cornerY = ($size * ($row)) - ($increment * $row)

		$format = "{0}x{0}+{1}+{2}" -f $size, $cornerX, $cornerY

		$dest = "C:\Users\Brian\Desktop\upscale\tiled\{0}.png" -f $outFile

		oiiotool $sourceFile --cut $format -o $dest

		$tile++
	}

	if($tile -gt $rowCount * $colCount)
	{
		break
	}
}